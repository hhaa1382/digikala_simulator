package Classes.Products;

public interface Warranty {
    double calculateGuaranteeValue();
    int calculateGuaranteeTime();
}
