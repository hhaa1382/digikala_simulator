package Classes.Exeptions;

public class ProductNotExist extends InvalidBuy{
    public ProductNotExist(){
        super(" : Product not exist!!");
    }
}
