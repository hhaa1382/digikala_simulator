package Classes.Exeptions;

public class InvalidPhoneNumber extends InvalidInput{
    public InvalidPhoneNumber(){
        super("Error : Phone number is not valid!!");
    }
}
