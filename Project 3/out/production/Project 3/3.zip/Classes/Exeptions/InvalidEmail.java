package Classes.Exeptions;

public class InvalidEmail extends InvalidInput{
    public InvalidEmail(){
        super(" : Email not valid!!");
    }
}
