package Classes.Exeptions;

public class NotEnoughMoney extends InvalidBuy{
    public NotEnoughMoney(){
        super(" : Money is not enough!!");
    }
}
